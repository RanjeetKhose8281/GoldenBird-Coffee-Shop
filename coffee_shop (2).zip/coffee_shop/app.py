from flask import Flask, render_template, request, redirect, url_for , flash
from flask import session
import os
import calendar
import pandas as pd
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATA_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Data')



def save_data(category, data):
    now = datetime.now()
    year = str(now.year)
    month = calendar.month_name[now.month]
    full_date = now.strftime('%d %B %Y')
    folder_path = os.path.join(DATA_FOLDER, year, month, full_date)
    os.makedirs(folder_path, exist_ok=True)
    file_path = os.path.join(folder_path, f"{category}.xlsx")

    df = pd.DataFrame([data])
    if os.path.exists(file_path):
        existing_df = pd.read_excel(file_path)
        df = pd.concat([existing_df, df], ignore_index=True)
    df.to_excel(file_path, index=False)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/apply_branch', methods=['POST'])
def apply_branch():
    try:
        # Get form data
        name = request.form['name']
        email = request.form['email']
        number = request.form['number']
        message = request.form['message']

        # Create folder path
        folder_path = os.path.join(DATA_FOLDER, "Branches")
        os.makedirs(folder_path, exist_ok=True)

        # Define Excel file path
        file_path = os.path.join(folder_path, "BranchApplications.xlsx")

        # Create a DataFrame from the form data
        data = {"Name": name, "Email": email, "Number": number, "Message": message}
        df = pd.DataFrame([data])

        # If file exists, read existing and append
        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            df = pd.concat([existing_df, df], ignore_index=True)

        # Save to Excel
        df.to_excel(file_path, index=False)

        # Redirect back to homepage
        flash("Application Submitted Successfully!", "success")
        return redirect(url_for('index'))

    except Exception as e:
        # Display error in browser
        return f"Error: {str(e)}"

@app.route('/advertise', methods=['POST'])
def advertise():
    try:
        # Get form data
        name = request.form['name']
        email = request.form['email']
        number = request.form['number']
        message = request.form['message']

        # Create folder path
        folder_path = os.path.join(DATA_FOLDER, "Advertisements")
        os.makedirs(folder_path, exist_ok=True)

        # Define Excel file path
        file_path = os.path.join(folder_path, "AdvertisementRequests.xlsx")

        # Create a DataFrame from the form data
        data = {"Name": name, "Email": email, "Number": number, "Message": message}
        df = pd.DataFrame([data])

        # If file exists, read existing and append
        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            df = pd.concat([existing_df, df], ignore_index=True)

        # Save to Excel
        df.to_excel(file_path, index=False)

        # Redirect back to homepage
        flash("Application Submitted Successfully!", "success")
        return redirect(url_for('index'))

    except Exception as e:
        # Display error in browser
        return f"Error: {str(e)}"



@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/menu')
def menu():
    return render_template('menu.html')

@app.route('/review', methods=['GET', 'POST'])
def review():
    now = datetime.now()
    year = str(now.year)
    month = f"{calendar.month_name[now.month]}-{year}"
    day_folder = now.strftime('%d-%B')

    folder_path = os.path.join(DATA_FOLDER, year, month, day_folder)
    os.makedirs(folder_path, exist_ok=True)

    file_path = os.path.join(folder_path, "review.xlsx")

    if request.method == 'POST':
        name = request.form['name']
        mobile = request.form['mobile']
        review_text = request.form['review']

        new_data = pd.DataFrame([{
            'Name': name,
            'Mobile': mobile,
            'Review': review_text,
            'Date': now.strftime('%Y-%m-%d %H:%M:%S')
        }])

        if os.path.exists(file_path):
            existing_data = pd.read_excel(file_path)
            updated_data = pd.concat([existing_data, new_data], ignore_index=True)
        else:
            updated_data = new_data

        updated_data.to_excel(file_path, index=False)
        return redirect('/review')

    # Only for GET: display existing reviews
    reviews = []
    if os.path.exists(file_path):
        df = pd.read_excel(file_path)
        df = df.sort_values(by='Date', ascending=False)
        reviews = df[['Name', 'Review']].to_dict(orient='records')

    return render_template('review.html', reviews=reviews)

@app.route('/order', methods=['GET', 'POST'])
def order():
    if request.method == 'POST':
        name = request.form['name']
        item_data = request.form['item']  # Format: "Latte|300"
        item_name, item_price = item_data.split("|")
        table_number = request.form['table_number']  # Get the table number
        quantity = int(request.form['quantity'])  # Get the quantity (convert to integer)

        # Calculate total price based on quantity
        total_price = int(item_price) * quantity

        now = datetime.now()
        year = str(now.year)
        month = f"{calendar.month_name[now.month]}-{year}"
        day_folder = now.strftime('%d-%B')

        folder_path = os.path.join(DATA_FOLDER, year, month, day_folder)
        os.makedirs(folder_path, exist_ok=True)

        file_path = os.path.join(folder_path, "Orders.xlsx")
        data = {"Name": name, "Order": item_name, "Price": total_price, "Quantity": quantity, "Table Number": table_number}
        df = pd.DataFrame([data])

        try:
            if os.path.exists(file_path):
                existing_df = pd.read_excel(file_path)
                df = pd.concat([existing_df, df], ignore_index=True)
            df.to_excel(file_path, index=False)
        except PermissionError:
            return "File is locked or open in another program. Please close Excel and try again."

        return render_template("order_Succesfull.html", name=name)

    return render_template("order.html")

 

@app.route('/book', methods=['GET', 'POST'])
def book():
    if request.method == 'POST':
        data = {
            "Name": request.form['name'],
            "Date": request.form['date'],
            "Time": request.form['time'],
            "Persons": request.form['persons']
        }
        now = datetime.now()
        year = str(now.year)
        month = f"{calendar.month_name[now.month]}-{year}"
        day_folder = now.strftime('%d-%B')

        folder_path = os.path.join(DATA_FOLDER, year, month, day_folder)
        os.makedirs(folder_path, exist_ok=True)

        file_path = os.path.join(folder_path, "bookings.xlsx")
        df = pd.DataFrame([data])
        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            df = pd.concat([existing_df, df], ignore_index=True)
        df.to_excel(file_path, index=False)

        flash("🎉 Booking successful! We look forward to serving you.")
        return redirect(url_for('book'))

    return render_template('book.html')



# Dictionary with coffee prices
coffee_prices = {
    "Cappuccino": 250,
    "Latte": 300,
    "Espresso": 200,
    "Mocha": 350,
    "Flat White": 150,
    "Affogato": 450,
    "Red Eye": 180,
    "Café au Lait": 450,
    "Frappe": 380,
    "Irish Coffee": 400
}

@app.route('/online_order', methods=['GET', 'POST'])
def online_order():
    if request.method == 'POST':
        # Retrieve form data
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        item = request.form['item']
        quantity = int(request.form['quantity'])
        payment_method = request.form['payment_method']

        # Get the price of the selected coffee
        price = coffee_prices.get(item.split('|')[0], 0)
        total_amount = price * quantity

        # Save the order data with address and phone
        save_order_data(name, item, quantity, total_amount, payment_method, address, phone)

        # Return appropriate page based on payment method
        if payment_method == 'Online Payment':
            return render_template('payment_qr.html',
                                   name=name,
                                   item=item,
                                   quantity=quantity,
                                   total_amount=total_amount,
                                   payment_method=payment_method)
        else:
            return render_template('Online_order_success.html',
                                   name=name,
                                   item=item,
                                   quantity=quantity,
                                   total_amount=total_amount,
                                   payment_method=payment_method)

    return render_template('online_order.html', coffee_prices=coffee_prices)


@app.route('/confirm_payment', methods=['POST'])
def confirm_payment():
    # Extract the data from the form submission
    name = request.form['name']
    item_name = request.form['item_name']
    quantity = int(request.form['quantity'])
    total_amount = float(request.form['total_amount'])
    payment_method = request.form['payment_method']

    # Save the confirmed payment details in the same way as other orders
    save_order_data(name, item_name, quantity, total_amount, payment_method)

    # After processing, show the confirmation success page
    return render_template('payment_success.html', 
                           name=name, 
                           item_name=item_name, 
                           quantity=quantity, 
                           total_amount=total_amount, 
                           payment_method=payment_method)


def save_order_data(name, item, quantity, amount, method, address=None, phone=None):
    now = datetime.now()
    year = str(now.year)
    month = f"{calendar.month_name[now.month]}-{year}"
    day_folder = now.strftime('%d-%B')

    # Create folder structure for saving data
    folder_path = os.path.join(DATA_FOLDER, year, month, day_folder)
    os.makedirs(folder_path, exist_ok=True)

    file_path = os.path.join(folder_path, "Online_order.xlsx")

    data = {
        "Name": name,
        "Item": item,
        "Quantity": quantity,
        "Amount": amount,
        "Payment Method": method,
        "Date": now.strftime('%Y-%m-%d'),
        "Time": now.strftime('%H:%M:%S')
    }

    # Add address and phone only if provided
    if address:
        data["Address"] = address
    if phone:
        data["Phone"] = phone

    # Save to Excel file
    df = pd.DataFrame([data])

    if os.path.exists(file_path):
        existing_df = pd.read_excel(file_path)
        df = pd.concat([existing_df, df], ignore_index=True)

    df.to_excel(file_path, index=False)
    print(f"Order saved to {file_path}")

@app.route('/bill', methods=['GET', 'POST'])
def bill():
    if request.method == 'POST':
        name = request.form['name']
        amount = request.form['amount']
        table = request.form['Table']
        method = request.form['method']

        now = datetime.now()
        year = str(now.year)
        month = f"{calendar.month_name[now.month]}-{year}"
        day_folder = now.strftime('%d-%B')
        folder_path = os.path.join(DATA_FOLDER, year, month, day_folder)
        os.makedirs(folder_path, exist_ok=True)

        file_path = os.path.join(folder_path, "Bill.xlsx")
        data = {"Name": name, "Amount": amount, "Table":table, "Method": method}
        df = pd.DataFrame([data])
        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            df = pd.concat([existing_df, df], ignore_index=True)
        df.to_excel(file_path, index=False)

        if method == "UPI":
            return render_template("upi_qr.html", name=name, amount=amount)
        else:
            return render_template("success.html", name=name)

    return render_template('bill.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        entered_username = request.form['username']
        entered_password = request.form['password']

        admin_file = os.path.join(DATA_FOLDER, "Admin.xlsx")
        if os.path.exists(admin_file):
            df = pd.read_excel(admin_file)

            # Print the columns and data to debug
            print("Columns in Admin.xlsx:", df.columns)
            print("Entered username:", entered_username)
            print("Entered password:", entered_password)

            # Check for matching username and password
            user = df[(df['Username'] == entered_username) & (df['Password'] == entered_password)]

            if not user.empty:
                session['admin'] = entered_username
                flash("Login successful.")
                return redirect(url_for('dashboard'))
            else:
                flash("Invalid username or password.")
        else:
            flash("Admin data file not found.")

    return render_template('login.html') 

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'admin' not in session:
        flash("Please login first.")
        return redirect(url_for('login'))

    # Default to today's date
    selected_date = datetime.now()
    if request.method == 'POST':
        try:
            selected_date = datetime.strptime(request.form['date'], '%Y-%m-%d')
        except:
            flash("Invalid date format. Please select a valid date.")

    year = str(selected_date.year)
    month = f"{calendar.month_name[selected_date.month]}-{year}"
    day_folder = selected_date.strftime('%d-%B')
    search_path = os.path.join(DATA_FOLDER, year, month, day_folder)

    data_tables = []

    if os.path.exists(search_path):
        for file in os.listdir(search_path):
            if file.endswith(".xlsx") and file != "Admin.xlsx":
                file_path = os.path.join(search_path, file)
                try:
                    df = pd.read_excel(file_path)
                    table_html = df.to_html(classes="data-table", index=False)

                    # Extract readable label
                    name = os.path.splitext(file)[0]  # 'Logins'
                    readable_date = selected_date.strftime('%d %B')
                    title = f"{name} of {readable_date}"

                    data_tables.append((title, table_html))
                except Exception as e:
                    print(f"Error reading {file_path}: {e}")
    else:
        flash("No data found for selected date.")

    return render_template("dashboard.html", admin=session['admin'], data_tables=data_tables, selected_date=selected_date.date())



if __name__ == '__main__':
    app.run(debug=True)
